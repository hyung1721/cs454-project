class APIBase:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def foo(self):
        print(self.a)

    def bar(self):
        print(self.b)


class SomeAPI(APIBase):
    def func1(self):
        self.foo()

    def func2(self):
        self.bar()


class OtherAPI(APIBase):
    def func1(self):
        self.foo()
        self.bar()
